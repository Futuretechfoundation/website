
[User's QuantumMedX component code omitted here for brevity in assistant message]
